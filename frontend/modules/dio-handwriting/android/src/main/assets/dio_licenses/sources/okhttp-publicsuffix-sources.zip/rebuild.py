import gzip,struct,pathlib
rows=[r for r in pathlib.Path('public_suffix_list.dat').read_bytes().splitlines() if r and not r.startswith(b'//')]
rules=b''.join(r+b'\n' for r in sorted(r for r in rows if not r.startswith(b'!')))
exceptions=b''.join(r[1:]+b'\n' for r in sorted(r for r in rows if r.startswith(b'!')))
payload=struct.pack('>I',len(rules))+rules+struct.pack('>I',len(exceptions))+exceptions
pathlib.Path('publicsuffixes.gz').write_bytes(gzip.compress(payload,mtime=0))
